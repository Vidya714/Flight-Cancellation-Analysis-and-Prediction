```python
import pandas as pd

import matplotlib.pyplot as plt

import seaborn as sns

import warnings

warnings.filterwarnings("ignore")





# 1. Load the data

df=pd.read_csv("C:\\Users\\vidya\\Downloads\\Flyzy Flight Cancellation - Sheet1.csv")

# 2. Descriptive statistics

print("=== Numerical summary ===")

print(df.describe())

print("\n=== Categorical summary ===")

print(df.describe(include=["object"]))

# 3. Distribution of numerical features

numeric_cols = [

  "Flight_Distance",

  "Scheduled_Departure_Time",

  "Day_of_Week",

  "Month",

  "Weather_Score",

  "Previous_Flight_Delay_Minutes",

  "Airline_Rating",

  "Passenger_Load"

]



sns.set(style="whitegrid")

plt.figure(figsize=(16, 12))

for i, col in enumerate(numeric_cols, 1):

  plt.subplot(3, 3, i)

  sns.histplot(df[col], kde=True, bins=30)

  plt.title(f"Distribution of {col}")

  plt.xlabel(col)

  plt.ylabel("Count")

plt.tight_layout()

plt.show()

# 4. Distribution of categorical features

cat_cols = ["Airline", "Origin_Airport", "Destination_Airport", "Airplane_Type", "Flight_Cancelled"]

plt.figure(figsize=(16, 8))

for i, col in enumerate(cat_cols, 1):

  plt.subplot(2, 3, i)

  sns.countplot(y=col, data=df, order=df[col].value_counts().index)

  plt.title(f"Count of {col}")

  plt.xlabel("Count")

  plt.ylabel(col)

plt.tight_layout()

plt.show()

# 6. Pairwise scatter plots colored by cancellation

sns.pairplot(

  df[numeric_cols + ["Flight_Cancelled"]],

  hue="Flight_Cancelled",

  vars=numeric_cols,

  palette="bright",

  diag_kind="hist",

  plot_kws={"alpha": 0.5}

)

plt.suptitle("Pairplot of Features vs Flight_Cancelled", y=1.02)

plt.show()

# 7. Feature vs target: boxplots / violinplots

plt.figure(figsize=(14, 6))

for i, col in enumerate(["Weather_Score", "Previous_Flight_Delay_Minutes", "Airline_Rating", "Passenger_Load"], 1):

  plt.subplot(2, 4, i)

  sns.boxplot(x="Flight_Cancelled", y=col, data=df)

  plt.title(f"{col} by Cancellation")

  plt.xlabel("Flight_Cancelled")

  plt.ylabel(col)

plt.tight_layout()

plt.show()



# Convert Flight_Cancelled to string for better labeling in plots

df["Flight_Cancelled"] = df["Flight_Cancelled"].astype(str)



# Bar plots for categorical vs Flight_Cancelled

plt.figure(figsize=(14, 10))

for i, col in enumerate(["Airline", "Airplane_Type"], 1):

  plt.subplot(1, 2, i)

  sns.countplot(x=col, hue="Flight_Cancelled", data=df)

  plt.title(f"{col} vs Flight_Cancelled")

  plt.xlabel(col)

  plt.ylabel("Count")

  plt.xticks(rotation=45)

plt.tight_layout()

plt.show()


```

    === Numerical summary ===
              Flight ID  Flight_Distance  Scheduled_Departure_Time  Day_of_Week  \
    count  3.000000e+03      3000.000000               3000.000000  3000.000000   
    mean   4.997429e+06       498.909333                 11.435000     3.963000   
    std    2.868139e+06        98.892266                  6.899298     2.016346   
    min    3.681000e+03       138.000000                  0.000000     1.000000   
    25%    2.520313e+06       431.000000                  6.000000     2.000000   
    50%    5.073096e+06       497.000000                 12.000000     4.000000   
    75%    7.462026e+06       566.000000                 17.000000     6.000000   
    max    9.999011e+06       864.000000                 23.000000     7.000000   
    
                 Month  Weather_Score  Previous_Flight_Delay_Minutes  \
    count  3000.000000    3000.000000                    3000.000000   
    mean      6.381000       0.524023                      26.793383   
    std       3.473979       0.290694                      27.874733   
    min       1.000000       0.000965                       0.000000   
    25%       3.000000       0.278011                       7.000000   
    50%       6.000000       0.522180                      18.000000   
    75%       9.000000       0.776323                      38.000000   
    max      12.000000       1.099246                     259.000000   
    
           Airline_Rating  Passenger_Load  Flight_Cancelled  
    count     3000.000000     3000.000000       3000.000000  
    mean         2.317439        0.515885          0.690667  
    std          1.430386        0.295634          0.462296  
    min          0.000103        0.001039          0.000000  
    25%          1.092902        0.265793          0.000000  
    50%          2.126614        0.517175          1.000000  
    75%          3.525746        0.770370          1.000000  
    max          5.189038        1.123559          1.000000  
    
    === Categorical summary ===
              Airline Origin_Airport Destination_Airport Airplane_Type
    count        3000           3000                3000          3000
    unique          5              5                   4             5
    top     Airline A      Airport 1           Airport 2        Type A
    freq         1147           1059                1651          1132
    


    
![png](output_0_1.png)
    



    
![png](output_0_2.png)
    



```python

```

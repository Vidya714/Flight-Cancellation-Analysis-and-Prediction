```python
# Import required libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# Load dataset
df=pd.read_csv("C:\\Users\\vidya\\Downloads\\Flyzy Flight Cancellation - Sheet1.csv")

# === Step 1: Check for Missing Values ===
print("Missing values per column:\n")
print(df.isnull().sum())
print("\nPercentage of missing values:\n")
print((df.isnull().sum() / len(df)) * 100)

# (No missing values found in this dataset, so no imputation/drop needed)

# === Step 2: Outlier Detection and Removal ===

# Select numerical columns
numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns

# Plot boxplots for visual inspection
plt.figure(figsize=(15, 10))
for i, col in enumerate(numerical_cols, 1):
    plt.subplot(3, 4, i)
    sns.boxplot(x=df[col])
    plt.title(col)
plt.tight_layout()
plt.show()

# Remove outliers using Z-score method
z_scores = stats.zscore(df[numerical_cols])
abs_z_scores = abs(z_scores)
filtered_entries = (abs_z_scores < 3).all(axis=1)
df_cleaned = df[filtered_entries]

print(f"\nOriginal dataset shape: {df.shape}")
print(f"Cleaned dataset shape: {df_cleaned.shape}")

# === Step 3: Check Data Types ===
print("\nData types of each column:\n")
print(df_cleaned.dtypes)

# Example: convert column if necessary
# df_cleaned['Scheduled_Departure_Time'] = pd.to_datetime(df_cleaned['Scheduled_Departure_Time'])

# === Step 4: Save Cleaned Dataset ===
df_cleaned.to_csv('Cleaned_Flyzy_Dataset.csv', index=False)
print("\nCleaned dataset saved as 'Cleaned_Flyzy_Dataset.csv'")

```

    Missing values per column:
    
    Flight ID                        0
    Airline                          0
    Flight_Distance                  0
    Origin_Airport                   0
    Destination_Airport              0
    Scheduled_Departure_Time         0
    Day_of_Week                      0
    Month                            0
    Airplane_Type                    0
    Weather_Score                    0
    Previous_Flight_Delay_Minutes    0
    Airline_Rating                   0
    Passenger_Load                   0
    Flight_Cancelled                 0
    dtype: int64
    
    Percentage of missing values:
    
    Flight ID                        0.0
    Airline                          0.0
    Flight_Distance                  0.0
    Origin_Airport                   0.0
    Destination_Airport              0.0
    Scheduled_Departure_Time         0.0
    Day_of_Week                      0.0
    Month                            0.0
    Airplane_Type                    0.0
    Weather_Score                    0.0
    Previous_Flight_Delay_Minutes    0.0
    Airline_Rating                   0.0
    Passenger_Load                   0.0
    Flight_Cancelled                 0.0
    dtype: float64
    


    
![png](output_0_1.png)
    


    
    Original dataset shape: (3000, 14)
    Cleaned dataset shape: (2939, 14)
    
    Data types of each column:
    
    Flight ID                          int64
    Airline                           object
    Flight_Distance                    int64
    Origin_Airport                    object
    Destination_Airport               object
    Scheduled_Departure_Time           int64
    Day_of_Week                        int64
    Month                              int64
    Airplane_Type                     object
    Weather_Score                    float64
    Previous_Flight_Delay_Minutes    float64
    Airline_Rating                   float64
    Passenger_Load                   float64
    Flight_Cancelled                   int64
    dtype: object
    
    Cleaned dataset saved as 'Cleaned_Flyzy_Dataset.csv'
    


```python

```
